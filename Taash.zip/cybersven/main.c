#include "raylib.h"
#include <string.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>



typedef struct  {
    Texture2D base;
    Texture2D defaul;
    Texture2D ace;
    Texture2D jack;
    Texture2D king;
    Texture2D queen;
    Texture2D numlist;
    
} guicard;
typedef struct 
    {
        int suit;
        int rank;
    }card;

    int gameexpander(card player[4][13],int game[4][2], card initial,int chance,int wincounter[4]);

card ai(card player[13],int game[4][2]){
        card canplay[13][2];
        int copyofgame[4][2];
        int count =0;
        int position;
        for(int a = 0; a<4 ;a++){
            for(int b = 0; b<2 ;b++){
                copyofgame[a][b]=game[a][b];
            }
        }
        for(int i =0;i<13;i++){
            if(player[i].rank==7){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[i].rank==copyofgame[player[i].suit][1]+1){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[i].rank==copyofgame[player[i].suit][0]-1){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
        }
        if(count==0){
            canplay[0][0].rank=0;
            canplay[0][0].suit=0;
            return canplay[0][0];
        }
        else{
            position= rand()%count;
            player[canplay[position][1].rank].rank=15;
            return canplay[position][0];
        } 
} 

int is_pass(card player[13],int game[4][2]){
        card canplay[13][2];
        int copyofgame[4][2];
        int count =0;
        int position;
        for(int a = 0; a<4 ;a++){
            for(int b = 0; b<2 ;b++){
                copyofgame[a][b]=game[a][b];
            }
        }
        for(int i =0;i<13;i++){
            if(player[i].rank==7){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[i].rank==copyofgame[player[i].suit][1]+1){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[i].rank==copyofgame[player[i].suit][0]-1){
                canplay[count][0]=player[i];
                canplay[count][1].rank=i;
                count++;
            }
        }
        if(count==0){
            return 1;
        }
        else{
            return 0;
        } 
}   

int is_cardplayable(card card,int game[4][2]){
    int copyofgame[4][2];
    
        for(int a = 0; a<4 ;a++){
            for(int b = 0; b<2 ;b++){
                copyofgame[a][b]=game[a][b];
            }
        }
        if(card.rank==copyofgame[card.suit][0]-1||card.rank==copyofgame[card.suit][1]+1||card.rank==7){
            return 1;
        }
        
        return 0;
        }
card play(card playcard,int game[4][2]){
       if(playcard.rank==0){
        
        }
       else if(playcard.rank>7){
        game[playcard.suit][1]=playcard.rank;
       }
       else if(playcard.rank<7){
        game[playcard.suit][0]=playcard.rank;
       }
       else if(playcard.rank==7){
        game[playcard.suit][1]=playcard.rank;
        game[playcard.suit][0]=playcard.rank;
       }
    }    

    card MSG_1(card player[4][13],int game[4][2],int chance,int wincounter[4]){
        card canplay[13][2];
        int copyofgame[4][2];
        card copyofplayer[4][13];
        int copyofwincounter[4];
        int chance2 = chance;
        int count =0;
        int position;
        for(int a = 0; a<4 ;a++){
            for(int b = 0; b<2 ;b++){
                copyofgame[a][b]=game[a][b];
            }
        }
        for(int i =0;i<13;i++){
            if(player[chance2][i].rank==7){
                canplay[count][0]=player[chance2][i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[chance2][i].rank==copyofgame[player[chance2][i].suit][1]+1){
                canplay[count][0]=player[chance2][i];
                canplay[count][1].rank=i;
                count++;
            }
            else if(player[chance2][i].rank==copyofgame[player[chance2][i].suit][0]-1){
                canplay[count][0]=player[chance2][i];
                canplay[count][1].rank=i;
                count++;
            }
        }
        printf("%d",count);
        position=0;
        int sum=0;
        int maxsum=0;
        if(count==0){
            canplay[0][0].rank=0;
            canplay[0][0].suit=0;
            return canplay[0][0];
        }
        else{
            for(int k=0; k <count;k++){
                    sum=0;
                    for(int h =0;h<2000;h++){
                            for(int a = 0; a<4 ;a++){
                            for(int b = 0; b<2 ;b++){
                                copyofgame[a][b]=game[a][b];
                            }
                            }
                            for(int a =0;a<4;a++){
                                copyofwincounter[a]=wincounter[a];
                            }
                            for(int a =0;a<4;a++){
                                for(int b = 0; b<13 ;b++){
                                copyofplayer[a][b]=player[a][b];
                            }
                            }
                            sum=sum+gameexpander(copyofplayer,copyofgame,canplay[k][0],chance2,copyofwincounter);


                    }
                    
                    if(sum>=maxsum){
                        maxsum=sum;
                        position=k;
                    }



            }

            
            player[chance2][canplay[position][1].rank].rank=15;
            return canplay[position][0];
        }
   }
   int gameexpander(card player[4][13],int game[4][2],card initial,int chance,int wincounter[4]){
    int b = chance;
    int check = chance;
    card playcard;
                playcard=ai(player[b],game);
                if(playcard.rank!=0){                
                    wincounter[b]++;
                }
                
                play(playcard,game);
                b++;
        while((wincounter[0]!=13)&&(wincounter[1]!=13)&&(wincounter[2]!=13)&&(wincounter[3]!=13)){
                if(b==4){
                    b=0;
                }
                playcard=ai(player[b],game);
                if(playcard.rank!=0){                
                    wincounter[b]++;
                }
                
                play(playcard,game);
                b++;
            
        }
        if(wincounter[check]==13){
            return 1;
        }
        else {
            return 0;
        }

   }    
    
    
void DrawCard(guicard card1,Vector2 Card_coord,card card){
    
    Vector2 position = Card_coord;
    Vector2 origin = {0,0};
    Rectangle crop ={0,0,30,50,BLANK};
    Rectangle dest = {position.x+20,position.y+20,24,40,BLANK};
    Color colour;
    
    
    switch (card.suit)
    {
    case 0:
        colour =PURPLE;
        
        break;
    case 1:
        colour =ORANGE;
        
        break;
    case 2:
        colour =BLUE;
        
        break;
    case 3:
        colour =GREEN;
       
        break;
    
    }
    DrawTexture(card1.base,Card_coord.x,Card_coord.y,colour);
    switch(card.rank){
        case 1:
            DrawTexture(card1.ace,Card_coord.x,Card_coord.y,colour);
                crop.x=(11)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(11)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;
        case 11:
            DrawTexture(card1.jack,Card_coord.x,Card_coord.y,colour);
                crop.x=(13)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(13)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;            
        case 12:
            DrawTexture(card1.queen,Card_coord.x,Card_coord.y,colour);
                crop.x=(12)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(12)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;
        case 13:
            DrawTexture(card1.king,Card_coord.x,Card_coord.y,colour);
                crop.x=(10)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(10)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;
        case 10:
            DrawTexture(card1.defaul,Card_coord.x,Card_coord.y,colour);
                crop.x=(0)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.x=(9)*30;
                dest.x=dest.x+25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                dest.x=dest.x-25;
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(0)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.x=(9)*30;
                dest.x=dest.x-25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                dest.x=dest.x+25;
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;
        default: 
                DrawTexture(card1.defaul,Card_coord.x,Card_coord.y,colour);
                crop.x=(card.rank-1)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=position.y+70;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,0,colour);
                crop.width=30;
                dest.width=24;
                dest.height=40;
                dest.x=position.x+205;
                dest.y=position.y+285;
                crop.x=(card.rank-1)*30;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                crop.width=50;
                crop.x=420+card.suit*50;
                dest.y=dest.y-50;
                dest.width=25;
                dest.height=25;
                DrawTexturePro(card1.numlist,crop,dest,origin,180,colour);
                
                    break;
            
    }



    
}

    void shuffle(card deck[52])
    {   int count =0;
        for(int g =0;g<4;g++){
            for(int h = 1 ;h<=13;h++){
                deck[count].suit=g;
                deck[count].rank=h;
                count++;
            }
        }
        
        int pointer;
        card temp;
        
        
        for(int t =51;t>0;t--){
            pointer=rand()%t;
            
            temp=deck[pointer];
            deck[pointer]=deck[t];
            deck[t]=temp;
        }
        
    }    








int main(void)
{
    srand(time(NULL));
    const int screenWidth = 1920;
    const int screenHeight = 1080;
    InitWindow(screenWidth, screenHeight, "./CYB3R5EV3N");
    InitAudioDevice();
    Texture2D title[22];
    Texture2D cell[2];
    Texture2D exit[2];
    Texture2D credits[2];
    Texture2D yes;
    Texture2D no;
    Texture2D neural = LoadTexture("table/neural.png");
    Texture2D you_sure = LoadTexture("table/pause.png");
    Texture2D indicator = LoadTexture("table/indicator.png");
    Texture2D pass = LoadTexture("table/pass.png");
    Texture2D console = LoadTexture("table/console.png");
    Texture2D winscreen = LoadTexture("table/winscreen.png");
    Vector2 mousePoint = { 0.0f, 0.0f };
    Rectangle collison1 = {20, 635, 410, 130, BLANK};
    Rectangle collison2 = {20, 785, 410, 130, BLANK};
    Rectangle collison = {20, 935, 410, 130, BLANK};
    
    
    Sound flicker = LoadSound("audio/flicker.wav");
    Sound clicked = LoadSound("audio/clicked.wav");
    Music ambience = LoadMusicStream("audio/am.wav");
    guicard Card_Res ={LoadTexture("card/base.png"),LoadTexture("card/default.png"),LoadTexture("card/ace.png"),LoadTexture("card/jack.png"),LoadTexture("card/king.png"),LoadTexture("card/queen.png"),LoadTexture("card/number.png")};
    title[0] = LoadTexture("screens/1.png");
    title[1] = LoadTexture("screens/2.png");
    title[2] = LoadTexture("screens/3.png");
    title[3] = LoadTexture("screens/4.png");
    title[4] = LoadTexture("screens/5.png");
    title[5] = LoadTexture("screens/6.png");
    title[6] = LoadTexture("screens/7.png");
    title[7] = LoadTexture("screens/8.png");
    title[8] = LoadTexture("screens/9.png");
    title[9] = LoadTexture("screens/10.png");
    title[10] = LoadTexture("screens/11.png");
    title[11] = LoadTexture("screens/12.png");
    title[12] = LoadTexture("screens/13.png");
    title[13] = LoadTexture("screens/14.png");
    title[14] = LoadTexture("screens/15.png");
    title[15] = LoadTexture("screens/16.png");
    title[16] = LoadTexture("screens/17.png");
    title[17] = LoadTexture("screens/18.png");
    title[18] = LoadTexture("screens/19.png");
    title[19] = LoadTexture("screens/20.png");
    title[20] = LoadTexture("screens/21.png");
    title[21] = LoadTexture("screens/22.png");
    
    
    no = LoadTexture("table/no_lit.png");

    
    yes = LoadTexture("table/yes_lit.png");


    cell[0] = LoadTexture("screens/cell_dim.png");
    cell[1] = LoadTexture("screens/cell_lit.png");

    exit[0] = LoadTexture("screens/exit_dim.png");
    exit[1] = LoadTexture("screens/exit_lit.png");

    credits[0] = LoadTexture("screens/credits_dim.png");
    credits[1] = LoadTexture("screens/credits_lit.png");
    PlayMusicStream(ambience);
    SetTargetFPS(60);            
    int a =0;
    int b =1;
    int c =0;
    int which_screen=0;
    int set_table =0;
    card player[4][13];
    card deck[52];
    card play_card;
    int game[4][2]={{30,30},{30,30},{30,30},{30,30}};
    int count=0;
    Vector2 player_main ={0,0};
    Rectangle which_card[13];
    int be_played=15;
    Vector2 coordofplayed;
    int wincounter[4]={0,0,0,0};
    int y_displace=0;
    int chance = 1;
    int fps_forchance=40;
    int ai_pass;
    int paused=0;
    int iswin=0;
    int fpsforanim=0;
    
    
                
    SetExitKey(KEY_NULL);            

    while (!WindowShouldClose()){  
        mousePoint = GetMousePosition();
        
        switch(which_screen){
            case 0:
                UpdateMusicStream(ambience);
                if(a==211)a=0;
                if(CheckCollisionPointRec(mousePoint,collison1 )&&IsMouseButtonDown(MOUSE_BUTTON_LEFT)){
                    //UnloadSound(flicker); 
                    PlaySound(clicked);  
                    //UnloadMusicStream(ambience);
                    which_screen =1;
                    set_table = 1;
                    }
                else if(CheckCollisionPointRec(mousePoint,collison2 )&&IsMouseButtonDown(MOUSE_BUTTON_LEFT)){

                    }
                else if(CheckCollisionPointRec(mousePoint,collison )&&IsMouseButtonDown(MOUSE_BUTTON_LEFT)){

                    }
                BeginDrawing();
                    ClearBackground(RAYWHITE);
                    DrawTexture(title[(int)(a/10)], 0, 0, RAYWHITE);

                    if(CheckCollisionPointRec(mousePoint,collison1 )){
                        if(b==1)PlaySound(flicker);
                        if((b<60)){
                            if((b%5)==0){
                                c=rand()%2;
                            }
                            DrawTexture(cell[c], 0, -300, RAYWHITE);
                            b++;
                            }
                        else{
                            DrawTexture(cell[1], 0, -300, RAYWHITE);
                            }
                        }
                    else{
                    DrawTexture(cell[0], 0, -300, RAYWHITE);
                        }



                    if(CheckCollisionPointRec(mousePoint,collison2 )){
                        if(b==1)PlaySound(flicker);
                        if((b<60)){
                            if((b%5)==0){
                                c=rand()%2;
                                }
                            
                            DrawTexture(credits[c], 0, -150, RAYWHITE);
                            b++;
                            }
                        else{
                            DrawTexture(credits[1], 0, -150, RAYWHITE);
                            }
                    }
                    else{
                        DrawTexture(credits[0], 0, -150, RAYWHITE);
                        
                        }


                
                    if(CheckCollisionPointRec(mousePoint,collison )){
                        if(b==1)PlaySound(flicker);
                        if((b<60)){
                            if((b%5)==0){
                                c=rand()%2;
                                }
                            
                            DrawTexture(exit[c], 0, 0, RAYWHITE);
                            b++;
                            }
                        else{
                            DrawTexture(exit[1], 0, 0, RAYWHITE);
                            }
                        }
                    else{
                        DrawTexture(exit[0], 0, 0, RAYWHITE);
                        
                        }

                    if(!(CheckCollisionPointRec(mousePoint,collison1 )||CheckCollisionPointRec(mousePoint,collison2 )||CheckCollisionPointRec(mousePoint,collison )))b=1;  
            
                    
                
                EndDrawing();
                a++;
                break;
        
        case 1:
            if(set_table==1){
                
                fps_forchance=40;
                shuffle(deck);
                
                count=0;
                for(int l =0;l<4;l++){
                    game[l][0]=30;
                    game[l][1]=30;
                }
               
                for(int l = 0; l<=12;l++){
                    player[0][l]=deck[count];
                    count++;
                    player[1][l]=deck[count];
                    count++;
                    player[2][l]=deck[count];
                    count++;
                    player[3][l]=deck[count];
                    count++;
                
                }
                wincounter[0]=0;
                wincounter[1]=0;
                wincounter[2]=0;
                wincounter[3]=0;
                iswin = 0;
                fpsforanim=0;
                set_table =0;
            }
             if(wincounter[0]==13||wincounter[1]==13||wincounter[2]==13||wincounter[3]==13)iswin=1;
            if(IsKeyPressed(KEY_ESCAPE))paused=1;
           


            be_played=15;
            if((GetMouseWheelMove()<0)&&(y_displace>=-280)){
                    y_displace=y_displace-30;
                }
            else if((GetMouseWheelMove()>0)&&(y_displace<=0)){
                    y_displace=y_displace+30;
                }    
            for(int which=0;which<13;which++){
                which_card[which].width=120;
                which_card[which].height=280;
                which_card[which].x=240+which*120;
                which_card[which].y=950+y_displace;
                if(CheckCollisionPointRec(mousePoint,which_card[which] )){
                    be_played=which;
                    if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)&&is_cardplayable(player[0][which],game)&&chance==0){
                        play(player[0][which],game);
                        player[0][which].rank=15;
                        wincounter[chance]++;
                        chance++;
                        
                    }
                    
                }
            }
            if(fps_forchance==120){
            if(chance==1||chance==2||chance==3){
                fps_forchance=0;
                play_card=MSG_1(player,game,chance,wincounter);
                if(play_card.rank!=0){                
                    wincounter[chance]++;
                    ai_pass=0;
                }
                else{
                    ai_pass=1;
                }
                
            }
            }
            if(fps_forchance==30){
                play(play_card,game);
            }
            if(fps_forchance==31){
                if(chance==3){
                    chance=0;
                    fps_forchance=40;
                }
                else{
                    chance++;
                }
            }
            
            BeginDrawing();
            
                ClearBackground(RAYWHITE);
                DrawTexture(neural,0,0+y_displace,RAYWHITE);
                player_main.x =0;
                player_main.y =950+y_displace;
                
                for(int l =0;l<4;l++){
                    if(game[l][0]==7){
                            Vector2 temp={425+l*280,412+y_displace};
                            card tempcard={l,game[l][0]};
                            
                            DrawCard(Card_Res,temp,tempcard);
                        }
                        if(game[l][1]==7){
                            Vector2 temp={425+l*280,412+y_displace};
                            card tempcard={l,game[l][1]};
                            
                            DrawCard(Card_Res,temp,tempcard);
                        }
                    for(int money=0;money<2;money++){
                        
                        
                        Vector2 temp={425+l*280,260+money*305+y_displace};
                        card tempcard={l,game[l][money]};
                        if(tempcard.rank!=30&&tempcard.rank!=7){
                        DrawCard(Card_Res,temp,tempcard);}
                        
                    }
                }
                if(be_played==15){
                    DrawTexture(indicator,0,915+y_displace,YELLOW);
                }
                else if (is_cardplayable(player[0][be_played],game)){
                    DrawTexture(indicator,0,915+y_displace,GREEN);
                }
                else{
                    DrawTexture(indicator,0,915+y_displace,RED);
                }
                for(int l = 1;l<4;l++){
                    char num[3];
                    sprintf(num,"%d",13-wincounter[l]);
                    DrawText(num,1145+l*230,20+y_displace,23,GREEN);
                }
                if(is_pass(player[0],game)){
                    Rectangle col = {1710,780+y_displace,195,105,BLANK};
                    DrawTexture(pass,1710,780+y_displace,RED);
                    if(CheckCollisionPointRec(mousePoint,col)){
                        DrawTexture(pass,1710,780+y_displace,GREEN);
                        if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)&&chance==0){
                            chance++;
                        }
                    }
                }

            if(fps_forchance<=30&&ai_pass==0){
                if(chance==1){
                    
                    if(play_card.rank>7){
                         
                        Vector2 intial = {0,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+1*305+y_displace}; 
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);
                    }
                    else if (play_card.rank<7){
                        
                        Vector2 intial = {0,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+0*305+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);
                    }
                    else{
                        Vector2 intial = {0,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,412+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);

                    }
                    
                    
                }
                if(chance==2){
                    if(play_card.rank>7){
                         
                        Vector2 intial = {820,-125+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+1*305+y_displace}; 
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);
                    }
                    else if (play_card.rank<7){
                        
                        Vector2 intial = {820,-125+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+0*305+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);
                    }
                    else{
                        Vector2 intial = {820,-125+y_displace};
                        Vector2 final = {425+play_card.suit*280,412+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);

                    }
                }
                if(chance==3){
                    if(play_card.rank>7){
                         
                        Vector2 intial = {1620,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+1*305+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card); 
                        
                    }
                    else if (play_card.rank<7){
                        
                        Vector2 intial = {1620,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,260+0*305+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);
                    }
                    else{
                        Vector2 intial = {1620,260+y_displace};
                        Vector2 final = {425+play_card.suit*280,412+y_displace};
                        float x = (final.x-intial.x)/30;
                        float y = (final.y-intial.y)/30;
                        intial.x = intial.x + (int)(x*fps_forchance);
                        intial.y = intial.y + (int)(y*fps_forchance);
                        DrawCard(Card_Res,intial,play_card);

                    }
                    
                }

            }
            if(paused==1&&iswin==0){
                DrawTexture(you_sure,372,380,RAYWHITE);
                Rectangle recyes = {1292,530,157,88,BLANK};
                Rectangle recno = {1292,418,157,88,BLANK};
                if(CheckCollisionPointRec(mousePoint,recyes)){
                    DrawTexture(yes,1292,530,RAYWHITE);
                    if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
                        paused=0;
                        which_screen=0;
                    }
                }
                else if(CheckCollisionPointRec(mousePoint,recno)){
                    DrawTexture(no,1292,418,RAYWHITE);
                    if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
                        paused=0;
                    }

                }

            }
            for(int main_pc=0;main_pc<13;main_pc++){
                    
                
                    if((player[0][main_pc].rank!=15)&&main_pc!=be_played){
                        player_main.x=240+main_pc*120;
                        DrawCard(Card_Res,player_main,player[0][main_pc]);
                        //player_main.x=player_main.x+120;
                        }
                    else if(main_pc==be_played&&(player[0][main_pc].rank!=15)){
                        coordofplayed.x=240+main_pc*120;
                        coordofplayed.y=850+y_displace;
                        DrawCard(Card_Res,coordofplayed,player[0][main_pc]);
                    }    
                    
                }
               
            DrawTexture(console,0,y_displace,RAYWHITE);
            if(iswin==1){
                float coord_y=((fpsforanim*583)/180)-583;
                DrawTexture(winscreen,365,y_displace+(int)coord_y,RAYWHITE);
                if(wincounter[0]==13){
                    DrawText("CONGRATULATIONS, YOU WON",485,100+(int)coord_y+y_displace,60,WHITE);
                }
                else if(wincounter[1]==13){
                    DrawText("DMITRI WON",755,100+(int)coord_y+y_displace,60,WHITE);
                }
                else if(wincounter[2]==13){
                    DrawText("LANA-69 WON",755,100+(int)coord_y+y_displace,60,WHITE);
                }
                else{
                    DrawText("MARCIN WON",755,100+(int)coord_y+y_displace,60,WHITE);
                }

                
                Rectangle recyes = {1300,360+y_displace+(int)coord_y,157,88,BLANK};
                Rectangle recno = {1100,360+y_displace+(int)coord_y,157,88,BLANK};
                if(CheckCollisionPointRec(mousePoint,recyes)){
                    DrawTexture(yes,1300,360+(int)coord_y+y_displace,RAYWHITE);
                    if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
                        
                        which_screen=0;
                        iswin=0;
                    }
                }
                else if(CheckCollisionPointRec(mousePoint,recno)){
                    DrawTexture(no,1100,360+(int)coord_y+y_displace,RAYWHITE);
                    if(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)){
                        set_table=1;
                    }

                }

            }
           
            EndDrawing();
            if(iswin==1&&fpsforanim<180)fpsforanim++;
            if(chance!=0&&paused==0&&iswin==0){
                fps_forchance++;
            }
            
            break;
   
    }
    }
    
    CloseAudioDevice();
    CloseWindow();        
    return 0;
}