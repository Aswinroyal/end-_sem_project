#include "raylib.h"

typedef struct  {
    Texture2D base;
    Texture2D spicifier;
    Texture2D numlist;
    
} guicard;
struct card
    {
        int suit;
        int rank;
    };
void DrawCard(guicard card1,Vector2 Card_coord,struct card card){
    DrawTexture(card1.base,0,0,PURPLE);
    Image image = LoadImageFromTexture(card1.numlist);

    DrawTexture(card1.spicifier,0,0,PURPLE);
    Vector2 position={20,20};
    Rectangle crop = {30,0,30,50,BLANK};
    ImageCrop(&image, crop);
    DrawTextureEx(LoadTextureFromImage(image),  position,0,1, PURPLE);
    position.x=195;
    position.y=285;
    DrawTextureEx(LoadTextureFromImage(image),  position,180,1, PURPLE);
}