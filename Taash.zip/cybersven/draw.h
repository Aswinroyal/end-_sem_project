
    
    Image image = LoadImageFromTexture(card1.numlist);
    Image suit = LoadImageFromTexture(card1.numlist);
    Image zero = LoadImageFromTexture(card1.numlist);
    Rectangle crop ={0,0,30,50,BLANK};
    ImageCrop(&zero, crop);
    Color colour;
    switch (card.suit)
    {
    case 0:
        colour =PURPLE;
        crop.width=50;
        crop.x=420;
        ImageCrop(&suit, crop);
        break;
    case 1:
        colour =ORANGE;
        crop.width=50;
        crop.x=420+50;
        ImageCrop(&suit, crop);
        break;
    case 2:
        colour =BLUE;
        crop.width=50;
        crop.x=420+100;
        ImageCrop(&suit, crop);
        break;
    case 3:
        colour =GREEN;
        crop.width=50;
        crop.x=420+150;
        ImageCrop(&suit, crop);
        break;
    
    }
    crop.width=30;
    DrawTexture(card1.base,Card_coord.x,Card_coord.y,colour);
    switch(card.rank){
        case 1:
        DrawTexture(card1.ace,Card_coord.x,Card_coord.y,colour);
        crop.x = 30*11;
        break;
        case 11:
        DrawTexture(card1.jack,Card_coord.x,Card_coord.y,colour);
        crop.x = 30*13;
        break;
        case 12:
        DrawTexture(card1.queen,Card_coord.x,Card_coord.y,colour);
        crop.x = 30*12;
        break;
        case 13:
        DrawTexture(card1.king,Card_coord.x,Card_coord.y,colour);
        crop.x = 30*10;
        break;
        default:
        DrawTexture(card1.defaul,Card_coord.x,Card_coord.y,colour);
        crop.x = (30*(card.rank-1));
        break;
    }
    Vector2 position={Card_coord.x+20,Card_coord.y+20};
    ImageCrop(&image, crop);
    if(card.rank==10){
        DrawTextureEx(LoadTextureFromImage(zero),  position,0,0.8, colour);
        position.x=position.x+25;
    }
    DrawTextureEx(LoadTextureFromImage(image),  position,0,0.8, colour);
    position.y=position.y+55;
    DrawTextureEx(LoadTextureFromImage(suit),  position,0,0.5, colour);
    
    position.x=Card_coord.x+195;
    position.y=Card_coord.y+285;
    if(card.rank==10){
        DrawTextureEx(LoadTextureFromImage(zero),  position,180,0.8, colour);
        position.x=position.x-25;
    }
    DrawTextureEx(LoadTextureFromImage(image),  position,180,0.8, colour);
    position.y=position.y-55;
    DrawTextureEx(LoadTextureFromImage(suit),  position,180,0.5, colour);
    
    position.x=Card_coord.x+80;
    position.y=Card_coord.y+125;
    
    if(card.rank<11&&card.rank!=1){
        DrawTextureEx(LoadTextureFromImage(suit),  position,0,1.2, colour);
    }
    else if(card.rank==1){
            position.x=Card_coord.x+95;
        position.y=Card_coord.y+135;
            DrawTextureEx(LoadTextureFromImage(suit),  position,0,0.7, colour);
    }
    else{
            position.x=Card_coord.x+105;
        position.y=Card_coord.y+140;
            DrawTextureEx(LoadTextureFromImage(suit),  position,0,0.5, colour);

    }